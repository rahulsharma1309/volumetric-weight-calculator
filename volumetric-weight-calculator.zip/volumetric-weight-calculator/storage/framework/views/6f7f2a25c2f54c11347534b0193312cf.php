<!DOCTYPE html>
<html>
<head>
    <title>Volumetric Lbs Result</title>
</head>
<body>
    <h1>Volumetric Lbs Result</h1>

    <p>Volumetric lbs: <?php echo e($volumetricLbs); ?> lbs</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\volumetric-weight-calculator\resources\views/result2.blade.php ENDPATH**/ ?>