<!DOCTYPE html>
<html>
<head>
    <title>Volumetric Weight Result</title>
</head>
<body>
    <h1>Volumetric Weight Result</h1>

    <p>Volumetric Weight: <?php echo e($volumetricWeight); ?> kg</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\volumetric-weight-calculator\resources\views/result.blade.php ENDPATH**/ ?>